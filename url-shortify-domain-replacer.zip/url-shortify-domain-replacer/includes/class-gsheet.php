<?php

if (!defined('ABSPATH')) {
    exit;
}

class USDR_GSheet {

    const SPREADSHEET_ID = '1XFv3f7L_is3ul4E5-wTo97QwfawcWab86BxJVtQuEqc';
    const CACHE_TTL = 900;
    const KEYS_TRANSIENT = 'usdr_gsheet_keys';
    const INDEX_TRANSIENT = 'usdr_gsheet_index';

    public static function spreadsheet_url() {
        return 'https://docs.google.com/spreadsheets/d/' . self::SPREADSHEET_ID . '/edit';
    }

    /**
     * @return array<int, array{name:string, gid:string}>|WP_Error
     */
    public static function get_brands() {
        $index = self::get_sheet_index();
        if (is_wp_error($index)) {
            return $index;
        }

        return $index;
    }

    /**
     * @return array<int, array{code:string, slug_count:int}>|WP_Error
     */
    public static function get_languages($brand) {
        $sheet = self::get_sheet_data($brand);
        if (is_wp_error($sheet)) {
            return $sheet;
        }

        $languages = [];
        foreach ($sheet['slugs_by_language'] as $code => $slugs) {
            $languages[] = [
                'code' => $code,
                'slug_count' => count($slugs),
            ];
        }

        usort($languages, static function ($a, $b) {
            return strcasecmp($a['code'], $b['code']);
        });

        return $languages;
    }

    /**
     * @return string[]|WP_Error
     */
    public static function get_slugs($brand, $language) {
        $sheet = self::get_sheet_data($brand);
        if (is_wp_error($sheet)) {
            return $sheet;
        }

        $language = self::normalize_text($language);
        if ($language === '') {
            return new WP_Error('missing_language', __('Please select a language.', 'us-domain-replacer'));
        }

        $map = [];
        foreach ($sheet['slugs_by_language'] as $code => $slugs) {
            $map[self::normalize_text($code)] = $slugs;
        }

        if (!isset($map[$language])) {
            return new WP_Error(
                'unknown_language',
                sprintf(
                    /* translators: 1: language, 2: brand/sheet name */
                    __('Language "%1$s" was not found for brand "%2$s".', 'us-domain-replacer'),
                    $language,
                    $brand
                )
            );
        }

        return array_values($map[$language]);
    }

    public static function clear_cache() {
        $keys = get_transient(self::KEYS_TRANSIENT);
        if (!is_array($keys)) {
            $keys = [];
        }

        $keys[] = self::KEYS_TRANSIENT;
        $keys[] = self::INDEX_TRANSIENT;

        foreach (array_unique($keys) as $key) {
            delete_transient($key);
        }

        return true;
    }

    /**
     * @return array<int, array{name:string, gid:string}>|WP_Error
     */
    private static function get_sheet_index() {
        $cached = get_transient(self::INDEX_TRANSIENT);
        if (is_array($cached) && !empty($cached)) {
            return $cached;
        }

        $html = self::remote_get(self::htmlview_url());
        if (is_wp_error($html)) {
            return $html;
        }

        $brands = [];
        $seen = [];

        if (preg_match_all('/items\.push\(\{name:\s*"([^"]+)",\s*pageUrl:\s*"[^"]+",\s*gid:\s*"([^"]+)"/', $html, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $name = html_entity_decode($match[1], ENT_QUOTES | ENT_HTML5, 'UTF-8');
                $name = trim(stripslashes($name));
                $gid = trim($match[2]);

                if ($name === '' || $gid === '' || isset($seen[$name])) {
                    continue;
                }

                $seen[$name] = true;
                $brands[] = [
                    'name' => $name,
                    'gid' => $gid,
                ];
            }
        }

        if (empty($brands)) {
            return new WP_Error(
                'gsheet_index',
                __('Could not read brand sheet names from Google Sheets. Confirm the spreadsheet is shared publicly.', 'us-domain-replacer')
            );
        }

        usort($brands, static function ($a, $b) {
            return strcasecmp($a['name'], $b['name']);
        });

        self::set_cache(self::INDEX_TRANSIENT, $brands);

        return $brands;
    }

    /**
     * @return array{name:string, gid:string, slugs_by_language:array<string, string[]>}|WP_Error
     */
    private static function get_sheet_data($brand) {
        $brand = trim((string) $brand);
        if ($brand === '') {
            return new WP_Error('missing_brand', __('Please select a brand.', 'us-domain-replacer'));
        }

        $index = self::get_sheet_index();
        if (is_wp_error($index)) {
            return $index;
        }

        $gid = '';
        $matched_name = '';
        foreach ($index as $item) {
            if (strcasecmp($item['name'], $brand) === 0) {
                $gid = $item['gid'];
                $matched_name = $item['name'];
                break;
            }
        }

        if ($gid === '') {
            return new WP_Error(
                'unknown_brand',
                sprintf(
                    /* translators: %s: brand/sheet name */
                    __('Brand "%s" was not found in Google Sheets.', 'us-domain-replacer'),
                    $brand
                )
            );
        }

        $cache_key = 'usdr_gsheet_rows_' . md5($gid);
        $cached = get_transient($cache_key);
        if (is_array($cached) && isset($cached['slugs_by_language'])) {
            return $cached;
        }

        $csv = self::remote_get(self::sheet_csv_url($gid));
        if (is_wp_error($csv)) {
            return $csv;
        }

        $rows = self::parse_csv($csv);
        if (empty($rows)) {
            return new WP_Error(
                'gsheet_empty',
                sprintf(
                    /* translators: %s: brand/sheet name */
                    __('Google Sheet "%s" returned no rows.', 'us-domain-replacer'),
                    $matched_name
                )
            );
        }

        $header = array_map([__CLASS__, 'normalize_header'], $rows[0]);
        $language_index = self::find_column_index($header, ['langauge', 'language'], 0);
        $slug_index = self::find_column_index($header, ['slug'], 1);

        $slugs_by_language = [];
        foreach (array_slice($rows, 1) as $row) {
            $language = isset($row[$language_index]) ? trim((string) $row[$language_index]) : '';
            $slug = isset($row[$slug_index]) ? trim((string) $row[$slug_index]) : '';

            if ($language === '' || $slug === '') {
                continue;
            }

            if (in_array(strtolower($language), ['langauge', 'language'], true) || strtolower($slug) === 'slug') {
                continue;
            }

            if (!isset($slugs_by_language[$language])) {
                $slugs_by_language[$language] = [];
            }

            $slugs_by_language[$language][$slug] = $slug;
        }

        foreach ($slugs_by_language as $language => $slugs) {
            $slugs_by_language[$language] = array_values($slugs);
        }

        if (empty($slugs_by_language)) {
            return new WP_Error(
                'gsheet_no_slugs',
                sprintf(
                    /* translators: %s: brand/sheet name */
                    __('No language/slug rows were found in Google Sheet "%s".', 'us-domain-replacer'),
                    $matched_name
                )
            );
        }

        $data = [
            'name' => $matched_name,
            'gid' => $gid,
            'slugs_by_language' => $slugs_by_language,
        ];

        self::set_cache($cache_key, $data);

        return $data;
    }

    private static function htmlview_url() {
        return 'https://docs.google.com/spreadsheets/d/' . self::SPREADSHEET_ID . '/htmlview';
    }

    private static function sheet_csv_url($gid) {
        return add_query_arg(
            [
                'tqx' => 'out:csv',
                'gid' => $gid,
                'tq' => 'select C,F',
            ],
            'https://docs.google.com/spreadsheets/d/' . self::SPREADSHEET_ID . '/gviz/tq'
        );
    }

    /**
     * @return string|WP_Error
     */
    private static function remote_get($url) {
        $response = wp_remote_get($url, [
            'timeout' => 25,
            'redirection' => 5,
            'headers' => [
                'User-Agent' => 'Mozilla/5.0 (compatible; URL-Shortify-Domain-Replacer/1.1)',
                'Accept' => 'text/csv,text/html,application/json;q=0.9,*/*;q=0.8',
            ],
        ]);

        if (is_wp_error($response)) {
            return new WP_Error(
                'gsheet_http',
                sprintf(
                    /* translators: %s: error message */
                    __('Google Sheets request failed: %s', 'us-domain-replacer'),
                    $response->get_error_message()
                )
            );
        }

        $code = (int) wp_remote_retrieve_response_code($response);
        $body = (string) wp_remote_retrieve_body($response);

        if ($code < 200 || $code >= 300 || $body === '') {
            return new WP_Error(
                'gsheet_http',
                sprintf(
                    /* translators: %d: HTTP status code */
                    __('Google Sheets returned HTTP %d. Make sure the spreadsheet is publicly viewable.', 'us-domain-replacer'),
                    $code
                )
            );
        }

        return $body;
    }

    /**
     * @return array<int, string[]>
     */
    private static function parse_csv($csv) {
        $csv = preg_replace('/^\xEF\xBB\xBF/', '', $csv);
        $lines = preg_split('/\r\n|\r|\n/', (string) $csv);
        $rows = [];

        foreach ($lines as $line) {
            if ($line === '' || $line === null) {
                continue;
            }
            $rows[] = str_getcsv($line);
        }

        return $rows;
    }

    private static function normalize_header($value) {
        return strtolower(trim((string) $value));
    }

    private static function normalize_text($value) {
        return strtoupper(trim((string) $value));
    }

    /**
     * @param string[] $header
     * @param string[] $names
     */
    private static function find_column_index(array $header, array $names, $fallback) {
        foreach ($names as $name) {
            $index = array_search($name, $header, true);
            if ($index !== false) {
                return (int) $index;
            }
        }

        return (int) $fallback;
    }

    private static function set_cache($key, $value) {
        set_transient($key, $value, self::CACHE_TTL);

        $keys = get_transient(self::KEYS_TRANSIENT);
        if (!is_array($keys)) {
            $keys = [];
        }

        if (!in_array($key, $keys, true)) {
            $keys[] = $key;
            set_transient(self::KEYS_TRANSIENT, $keys, DAY_IN_SECONDS);
        }
    }
}
